package com.bambamsingh.newsdemo.base;

import android.content.Context;

import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {
    public Context _context;
} 